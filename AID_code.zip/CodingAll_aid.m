clc;
clear;
close all;

datasetname = 'aid/';
localfeaturename = {'ch','lbp256','sift'};%
localfeaturedir = strcat('./temp_data/localfeature/',datasetname);
samplingname = {'grid'};
clusteringsetdir = strcat('./temp_data/clusteringset/',datasetname);
codingname = {'bow','spm','llc','plsa','lda','ifk','vlad'};%
savedir = strcat('./temp_data/glofeat/final/',datasetname);
mkdir (savedir);
params.gridSpacing = 8;
params.patchSize = 16;

for lf = 1: length(localfeaturename)
    for sp = 1: length(samplingname)
        for cd = 1: length(codingname)
%             for i = 1:7
             switch codingname{cd}
                case {'bow'}
                    params.dicSize = 4096;%2.^(i+6)
                case {'spm'}
                    params.dicSize = 256;%2.^(i+6);%128
                case {'plsa'}
                    params.dicSize = 1024;%2.^(i+6);%1024;
                case {'lda'}
                    params.dicSize = 1024;%2.^(i+6);%1024;
                case {'llc'}
                    params.dicSize = 4096;%2.^(i+6);%8192;
                case {'ifk'}
                    params.dicSize = 128;%2.^(i+3);%32;
                case {'vlad'}
                    params.dicSize = 128;%2.^(i+3);%64;
            end
            
            globalfeatureall = CodingAll_Small_file( localfeaturename{lf}, localfeaturedir, ...
                samplingname{sp}, clusteringsetdir, codingname{cd}, savedir, params);
%             end
         end
    end
end

%% extract mid-level features for the dataset
clc
clear
close all

% extract local features
LocalFeatureAll_aid;

% random sampling the clusteringset
GetClusteringSet_aid;

% coding the local features
CodingAll_aid;


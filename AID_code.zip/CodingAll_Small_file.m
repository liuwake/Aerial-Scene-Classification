function [ globalfeatureall ] = CodingAll( localfeaturename, localfeaturepath, ...
    samplingname, clusteringsetpath, codingname, savepath, params )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
globalfeaturename = fullfile(savepath, sprintf('globalfeatureall_%s_%s_%s_%d.mat',localfeaturename, ...
    samplingname,codingname,params.dicSize));
if(exist(globalfeaturename,'file')~=0)
    fprintf('%s already exists.\n', globalfeaturename);
    load (globalfeaturename);
    return
else
    
    clusteringsetname = sprintf('clusteringset_%s_%d_%d.mat',localfeaturename, ...
        params.gridSpacing,params.patchSize);
    dictionaryname = fullfile(savepath, sprintf('dictionary_%s_%s_%d_%d_%d.mat',localfeaturename, ...
        codingname,params.gridSpacing, params.patchSize, params.dicSize));
    
    if(exist(dictionaryname,'file')~=0)
        fprintf('%s already exists.\n', dictionaryname);
        load (dictionaryname);
    else
        if (strcmp(codingname,'spm')||strcmp(codingname,'plsa')||strcmp(codingname,'lda'))
            dictionaryname = fullfile(savepath, sprintf('dictionary_%s_bow_%d_%d_%d.mat',localfeaturename, ...
                params.gridSpacing, params.patchSize, params.dicSize));
            if (exist(dictionaryname,'file')~=0)
                fprintf('%s already exists.\n', dictionaryname);
                load (dictionaryname);
            else
                load (strcat(clusteringsetpath,clusteringsetname));
                dictionary = DictionaryLearning( ClusteringSet, codingname, params );
                save (dictionaryname, 'dictionary');
            end
        else
            load (strcat(clusteringsetpath,clusteringsetname));
            dictionary = DictionaryLearning( ClusteringSet, codingname, params );
            save (dictionaryname, 'dictionary');
        end
    end
    
    fnames = dir(localfeaturepath);
    num_files = size(fnames,1);
    num_class = num_files-2;
    num_img_per_class = zeros(num_class,1);
    
    temppath = strcat(savepath, '/temp_small/');
    mkdir(temppath);
    globalfeatureall = [];
    
    for i = 1:num_files%�����ļ����ж�ȡͼƬ
        
        if( (strcmp(fnames(i).name , '.')==1) || (strcmp(fnames(i).name , '..')==1))
            continue;
        end
        globalfeatureclass = [];
        outfile = strcat(temppath,sprintf('class%d_%s_%s_%s.mat', (i-2), localfeaturename, samplingname, codingname));
        %         if(exist(outfile,'file')~=0)
        %             fprintf('Already exist %s\n', outfile);
        %             load (outfile);
        %             globalfeatureall = [globalfeatureall; single(globalfeatureclass)];
        %
        %             continue;
        %         end
        
        subfoldername = fnames(i).name;
        filename_lf = dir(fullfile(strcat(localfeaturepath,subfoldername,'/'),sprintf('*_%s_*.mat',localfeaturename)));
        num_img_per_class(i-2) = length(filename_lf);
        
        for j=1:num_img_per_class(i-2)
            
            load (strcat(localfeaturepath,subfoldername,'/',filename_lf(j).name));
            localfeature = features;
            globalfeature = Coding(localfeature, dictionary, codingname, params );
            globalfeatureclass = [globalfeatureclass; single(globalfeature)];
            j
            i
        end
        save(outfile, 'globalfeatureclass');
        globalfeatureall = [globalfeatureall; single(globalfeatureclass)];
    end
    
end
switch codingname
    case {'bow','spm','llc','ifk','vlad'}
        globalfeatureall = globalfeatureall;
        %     case {'ifk','vlad'}
        %         [mappedX, mapping] = compute_mapping(globalfeatureall, 'PCA', 1024);
        %         globalfeatureall = mappedX;
    case 'plsa'
        counts=globalfeatureall';
        options.var_beta=0;
        options.var_gamma=0;
%         t = params.dicSize./2;
        t = 64;
        [model, gammas, E,F] = LDA_variational_inference( counts, t, options);
        globalfeatureall=gammas.dp';
    case 'lda'
        counts=globalfeatureall';
%         t = params.dicSize./2;
        t = 64;
        [model, gammas, E,F] = LDA_variational_inference( counts, t, []);
        globalfeatureall=gammas.dp';
end
% savename = fullfile(savepath, sprintf('globalfeatureall_%s_%s_%s.mat',localfeaturename, ...
%     samplingname, codingname));
save(globalfeaturename, 'globalfeatureall','-v7.3')
end




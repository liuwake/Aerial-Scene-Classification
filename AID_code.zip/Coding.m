function [ globalfeature ] = Coding( localfeature, dictionary, codingname, params )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

switch codingname
    case {'bow','plsa','lda'}

        dictionarySize = size(dictionary.dic, 1);
        dist_mat = sp_dist2(localfeature.data, dictionary.dic);
        [min_dist, min_ind] = min(dist_mat, [], 2);
        globalfeature = hist(min_ind, 1:dictionarySize);
        
    case 'spm'
        if(~isfield(params,'level'))
            params.level = 2;
        end

        ndata = size(localfeature.data, 1);
        texton_ind.data = zeros(ndata,1);
        texton_ind.x = localfeature.x;
        texton_ind.y = localfeature.y;
        hgt = localfeature.hgt;
        wid = localfeature.wid;
        binsHigh = 2^(params.level - 1);
        num_bins = binsHigh/2;
        dictionarySize = size(dictionary.dic, 1);
        
        dist_mat = sp_dist2(localfeature.data, dictionary.dic);
        [min_dist, min_ind] = min(dist_mat, [], 2);
        texton_ind.data = min_ind;
        
        for i=1:binsHigh
            for j=1:binsHigh
                
                % find the coordinates of the current bin
                x_lo = floor(wid/binsHigh * (i-1));
                x_hi = floor(wid/binsHigh * i);
                y_lo = floor(hgt/binsHigh * (j-1));
                y_hi = floor(hgt/binsHigh * j);
                
                texton_patch = texton_ind.data( (texton_ind.x > x_lo) & (texton_ind.x <= x_hi) & ...
                    (texton_ind.y > y_lo) & (texton_ind.y <= y_hi));
                
                % make histogram of features in bin
                pyramid_cell{1}(i,j,:) = hist(texton_patch, 1:dictionarySize)./length(texton_ind.data);
            end
        end
        for l = 2:params.level
            pyramid_cell{l} = zeros(num_bins, num_bins, dictionarySize);
            for i=1:num_bins
                for j=1:num_bins
                    pyramid_cell{l}(i,j,:) = ...
                        pyramid_cell{l-1}(2*i-1,2*j-1,:) + pyramid_cell{l-1}(2*i,2*j-1,:) + ...
                        pyramid_cell{l-1}(2*i-1,2*j,:) + pyramid_cell{l-1}(2*i,2*j,:);
                end
            end
            num_bins = num_bins/2;
        end
        
        globalfeature = [];
        for l = 1:params.level-1
            globalfeature = [globalfeature pyramid_cell{l}(:)' .* 2^(-l)];
        end
        globalfeature = [globalfeature pyramid_cell{params.level}(:)' .* 2^(1-params.level)];
        
    case 'llc'
        kdtree = vl_kdtreebuild(dictionary.dic', 'numTrees', 2) ;
        ix = vl_kdtreequery(kdtree, dictionary.dic', localfeature.data',...
            'MaxComparisons', 15, 'NumNeighbors', 5);
        globalfeature = LLCEncodeHelper(double(dictionary.dic'), double(localfeature.data'), ...
            double(ix), double(1e-4), false);
        globalfeature = globalfeature';
        
    case 'ifk'
        dictionarySize = size(dictionary.dic, 1);
        dimensionSize = size(dictionary.dic, 2);
        globalfeature = histogr(localfeature.data, dictionary.dic, dictionarySize, dimensionSize);
%         mappingMatrix = dictionary.mappingMatrix;
%         dr = size(dictionary.mappingMatrix, 2);
%         features_dr = double(samplingfeature.data * mappingMatrix );
%         globalfeature = histogr(features_dr, dictionary.dic, dictionarySize, dr);
        
    case 'vlad'
        dictionarySize = size(dictionary.dic, 1);
        dimensionSize = size(dictionary.dic, 2);
%         mappingMatrix = dictionary.mappingMatrix;
%         dr = size(dictionary.mappingMatrix, 2);
%         features_dr = single(samplingfeature.data * mappingMatrix);
        kdtree = vl_kdtreebuild(single(dictionary.dic')) ;
        nn = vl_kdtreequery(kdtree, single(dictionary.dic'), localfeature.data') ;
        numDataToBeEncoded = size(localfeature.data,1);
        assignments = single(zeros(dictionarySize,numDataToBeEncoded));
        assignments(sub2ind(size(assignments), single(nn), 1:length(nn))) = single(1);
        enc = vl_vlad(localfeature.data',single(dictionary.dic'),assignments);
        globalfeature = double(enc');
        
end
end

function H = histogr(imfeatures, dictionary, dictionarySize,dimensionSize)
imfeature = double(imfeatures);
if( size(imfeature,1) > 0 )
    H1 = vl_fisher(imfeature', dictionary.means, dictionary.covariances, dictionary.priors,'Improved');
    H1 = H1';
else
    H1 = zeros(1,dictionarySize*2*dimensionSize);
end

H = H1;
end


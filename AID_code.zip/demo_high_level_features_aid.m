%% extract high-level features for the dataset
clc
clear
close all

datasetname = 'aid/';
localfeaturename = {'sift','lbp256','ch'};
imagedir = strcat('../../images/',datasetname);
savedir = strcat('./temp_data/glofeat/',datasetname);
mkdir (savedir);
num_img_all = 10000;
fnames = dir(imagedir);
num_files = size(fnames,1);
filenames = cell(num_img_all,1);
num_class = num_files-2;
num_img_per_class = zeros(num_class,1);

for i = 1:num_files
        
        if( (strcmp(fnames(i).name , '.')==1) || (strcmp(fnames(i).name , '..')==1))
            continue;
        end
        subfoldername = fnames(i).name;
        filename_tif = dir(fullfile(strcat(imagedir,subfoldername),'*.jpg'));
        num_img_per_class(i-2) = length(filename_tif);
        for j=1:num_img_per_class(i-2)
            filenames{sum(num_img_per_class(1:i-3))+j,1} = strcat(imagedir,'/',subfoldername,'/',filename_tif(j).name);
        end
        
    end

%% for caffenet
%initialized setting
cnn_model = 'imagenet-caffe-ref.mat';
net = load(['../../cnn_models/' cnn_model]);

%gpu version
% net = vl_simplenn_move(net, 'gpu');

%compute conv features
denseFeatures = cell(1, num_img_all);

params = struct;
params.aug_frames = false;
params.sqrt_map = false;
params.normalize = true;

%compute CNN features
disp('computing dense CNN features');
tic
for i = 1:num_img_all
    im = imread(filenames{i,1});
    
    % Pre-processing image for CNN
    img = single(im);
    %     img_avg = zeros(256,256,3);
    %     img_avg(:,:,1)=net.meta.normalization.averageImage(1);
    %     img_avg(:,:,2)=net.meta.normalization.averageImage(2);
    %     img_avg(:,:,3)=net.meta.normalization.averageImage(3);
    
    img_avg = imresize((net.meta.normalization.averageImage), [size(img,1) size(img,2)]);
    im = img - img_avg;
    %for fc
    im = imresize(im, [net.meta.normalization.imageSize(1:2)]);
    
    %     scale = 1;
    %     im = imresize(im,scale);
    res = vl_simplenn(net, im);
    y = res(17).x; %for fc6
    
    feats = reshape(y, size(y,1) * size(y,2), size(y,3));
    feats = feats';
    
    if params.sqrt_map
        feats = sign(feats).*sqrt(abs(feats));
    end
    
    if params.aug_frames
        [xPos, yPos] = meshgrid([1:size(y,2)], [1:size(y,1)]);
        xyPos = cat(3, xPos/size(y,2), yPos/size(y,1));
        sp_aug = reshape(xyPos, size(y,1) * size(y,2), 2);
        feats = cat(1, feats, sp_aug');
    end
    
    if params.normalize
        feats = normc(feats);
    end
    denseFeatures{i} = feats;
    i
end
toc
disp('Done');
save(strcat(savedir,'caffe_fc.mat'), 'denseFeatures','-v7.3');
% net = vl_simplenn_move(net, 'cpu');


%% for vgg-vd-16
% initialized setting
cnn_model = 'imagenet-vgg-verydeep-16.mat';
net = load(['./cnn_models/' cnn_model]);

% gpu version
% net = vl_simplenn_move(net, 'gpu');

% compute conv features
denseFeatures = cell(1, num_img_all);

params = struct;
params.aug_frames = false;
params.sqrt_map = false;
params.normalize = true;

% compute CNN features
disp('computing dense CNN features');
tic
for i = 1:num_img_all
    im = imread(filenames{i,1});

    % Pre-processing image for CNN
    img = single(im);
    %     img_avg = zeros(256,256,3);
    %     img_avg(:,:,1)=net.meta.normalization.averageImage(1);
    %     img_avg(:,:,2)=net.meta.normalization.averageImage(2);
    %     img_avg(:,:,3)=net.meta.normalization.averageImage(3);
    
    img_avg = imresize((net.meta.normalization.averageImage), [size(img,1) size(img,2)]);
    im = img - img_avg;
    %for fc
    im = imresize(im, [net.meta.normalization.imageSize(1:2)]);
    
    %     scale = 1;
    %     im = imresize(im,scale);
    res = vl_simplenn(net, im);
    y = res(33).x; %for fc6
    
    feats = reshape(y, size(y,1) * size(y,2), size(y,3));
    feats = feats';
    
    if params.sqrt_map
        feats = sign(feats).*sqrt(abs(feats));
    end
    
    if params.aug_frames
        [xPos, yPos] = meshgrid([1:size(y,2)], [1:size(y,1)]);
        xyPos = cat(3, xPos/size(y,2), yPos/size(y,1));
        sp_aug = reshape(xyPos, size(y,1) * size(y,2), 2);
        feats = cat(1, feats, sp_aug');
    end
    
    if params.normalize
        feats = normc(feats);
    end
    denseFeatures{i} = feats;
    i
end
toc
disp('Done');
save(strcat(savedir,'vggvd16_fc.mat'), 'denseFeatures','-v7.3');
% net = vl_simplenn_move(net, 'cpu');

%% for googlenet
% compute GoogleNet features
cnn_model = 'imagenet-googlenet-dag';
% load the pre-trained CNN
net = dagnn.DagNN.loadobj(load(['./cnn_models/', cnn_model])) ;

net.conserveMemory = false;

denseFeatures = cell(1, num_img_all);

% extract fully-connected features from the last Inception module
for i = 1:num_img_all
    oriImg = imread(filenames{i,1});
    img = single(oriImg);
    img = imresize(img, net.meta.normalization.imageSize(1:2));
    img = img - net.meta.normalization.averageImage;
    net.eval({'data', img});
    tempfea = gather(net.vars(net.getVarIndex('cls3_pool')).value); % for fc
    tempfea = squeeze(tempfea)';
    denseFeatures{i} = tempfea';
    i
%     toc;
end

disp('Done');
save(strcat(savedir,'googlenet_fc.mat'), 'denseFeatures','-v7.3');   





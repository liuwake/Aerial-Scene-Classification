Object detection (e.g. boats) is challenging enough to be interesting, but of broad enough interest that there are many datasets?

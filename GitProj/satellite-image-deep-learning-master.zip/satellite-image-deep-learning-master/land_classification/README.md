This folder contains my effort on land classification. My approach was to use transfer learning with a CNN.
